const express = require('express');
const app = express();
const port = 4329;

const path = require('path');

let initialpath = path.join(__dirname, "src");

app.get("/", (req, res) => {
    res.sendFile(path.join(initialpath, "home.html"))
})

app.get("/activities", (req, res) => {
    res.sendFile(path.join(initialpath, "activities.html"))
})

app.get("/gpt", (req, res) => {
    res.sendFile(path.join(initialpath, "gpt.html"))
})

app.get("/license", (req, res) => {
    res.sendFile(path.join(initialpath, "licen.md"))
})

app.use(express.static(initialpath));
app.use(express.Router);

app.listen(port, () => {
    console.log(`Server is running on port: ${port}`);
});
