// Variables Start

const searchBar = document.querySelector(".searchbar");
const fileContainer = document.querySelector(".files");

const fileDisplay = document.querySelector(".filecontainer");

const backButton = document.querySelector(".back");
const fullScreen = document.querySelector(".fullscreen");

// Variables End


// Searchbar Start

searchBar.addEventListener('input', (e) => {
    const query = searchBar.value.trim().toLowerCase();


    for (let file of fileContainer.children) {
        if (file instanceof Element) {
            if (query) {
                const fileName = file.querySelector('span').innerText.trim().toLowerCase();

                if (fileName.includes(query)) {
                    file.classList.remove('hidden');
                } else {
                    file.classList.add('hidden');
                }
            } else {
                file.classList.remove('hidden')
            }
        }
    }
});


// Searchbar End

// File Handler Start

fetch("/json/files.json")
    .then((response) => response.json)
    .then((files) => {
        files.foreach((file) => {
            const fileEl = document.createElement('div');
            fileEl.classname = "file";
            fileEl.innerHTML = `<img src="${"CDN HERE" + file.root + "/" + file.logo}" /><span class="fileName">${file.name}</span>`;

            fileContainer.appendChild(fileEl);

            fileEl.onclick = (e) => {
                fileContainer.classList.add('hidden');
                searchBar.classList.add('hidden');

                fileDisplay.classList.remove('hidden');

                fileDisplay.querySelector(
                    "iframe"
                ).src = `${`CDN HERE` + file.root + "/" + file.file}`
            }

            backButton.onclick = (e) => {
                fileContainer.classList.remove('hidden');
                searchBar.classList.remove('hidden');

                fileDisplay.classList.add('hidden');

                fileDisplay.querySelector(
                    "iframe"
                ).src = "";
            }

            const toggleFullScreen = () => {
                fileDisplay.querySelector('iframe').requestFullscreen();
            }
        })
    })

// File Handler End


